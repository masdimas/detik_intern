<!doctype html>
<html lang="en">
<?php include "component/head.php"; ?>

<body>
    <?php include "section/home/navbar.php"; ?>
    <?php include "section/home/headline.php"; ?>
    <?php include "component/snk.php"; ?>
    <?php include "section/home/footer.php"; ?>
</body>
<?php include "component/foot.php"; ?>

</html>