<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Festival Creative LPS</title>
    <link rel="stylesheet" href="./src/css/bootstrap-5.3.1/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./src/css/swiperjs/swiper-bundle.min.css" />
    <link type="image/x-icon" rel="shortcut icon" href="https://cdn.detik.net.id/detikcom/images/favicon.ico?v=2023080115111">

    <link rel="stylesheet" href="src/css/main.css">
    <link rel="stylesheet" href="src/css/navbar.css">
    <link rel="stylesheet" href="src/css/footer.css">
    <link rel="stylesheet" href="src/css/snk.css">
    <link rel="stylesheet" href="src/css/finalist.css">
    <link rel="stylesheet" href="src/css/roadshow.css">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>

</head>