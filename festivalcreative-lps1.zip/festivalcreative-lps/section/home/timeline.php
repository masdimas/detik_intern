<div id="timeline">
    <div class="container">
        <div class="timeline-wrap">
            <img class="img-fluid d-none d-sm-block" src="./src/image/home/timeline/timeline.png" alt="">
            <img class="img-fluid d-block d-sm-none" src="./src/image/home/timeline/timeline-mobile.png" alt="">
        </div>
    </div>
</div>