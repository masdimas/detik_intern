<div id="banner">
    <div class="container">
        <div class="banner-wrap">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                            <img class="banner-desktop img-fluid d-none d-sm-block" src="./src/image/home/banner/banner-3.png" alt="">
                            <img class="banner-mobile img-fluid d-block d-sm-none" src="./src/image/home/banner/banner-mobile-3.png" alt="">
                    </div>
                    <div class="swiper-slide">
                        <a href="{clickurl}">
                            <img class="banner-desktop img-fluid d-none d-sm-block" src="./src/image/home/banner/banner-1_1.png" alt="">
                            <img class="banner-mobile img-fluid d-block d-sm-none" src="./src/image/home/banner/banner-mobile-1_1.png" alt="">
                        </a>
                    </div>
                    <div class="swiper-slide">
                        <a href="{clickurl}">
                            <img class="banner-desktop img-fluid d-none d-sm-block" src="./src/image/home/banner/banner-1.png" alt="">
                            <img class="banner-mobile img-fluid d-block d-sm-none" src="./src/image/home/banner/banner-mobile-1.png" alt="">
                        </a>
                    </div>
                    <div class="swiper-slide">
                        <a href="{clickurl}">
                            <img class="banner-desktop img-fluid d-none d-sm-block" src="./src/image/home/banner/banner-2.png" alt="">
                            <img class="banner-mobile img-fluid d-block d-sm-none" src="./src/image/home/banner/banner-mobile-2.png" alt="">
                        </a>
                    </div>
                </div>

                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</div>