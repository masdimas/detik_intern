<div id="headline">
    <div class="container">
        <div class="headline justify-center">
            <div class="row justify-content-center align-items-center">
                <div class="col-12">
                    <img class="mx-auto d-block" src="./src/image/home/headline/headline-mobile.png" alt="">
                </div>
            </div>
        </div>
        <div class="sub-headline justify-center">
            <div class="row justify-content-center align-items-center">
                <div class="col-12">
                    <img class="mx-auto d-block" src="./src/image/home/headline/cta.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>