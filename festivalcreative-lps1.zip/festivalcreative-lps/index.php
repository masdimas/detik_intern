<!doctype html>
<html lang="en">
<?php include "component/head.php"; ?>
<body>
<?php include "section/home/navbar.php"; ?>
    <?php include "section/home/headline.php"; ?>
    <?php include "section/home/form.php"; ?>
    <?php include "section/home/banner.php"; ?>
    <?php include "section/home/new-snk.php"; ?>
    <?php include "section/home/timeline.php"; ?>
    <?php include "section/home/footer.php"; ?>
</body>
<?php include "section/home/form-modal.php"; ?>
<?php include "component/foot.php"; ?>
</html>